def binary_search_hoare(A, x):
    # Precondition: A must be sorted
    assert A == sorted(A), "Precondition failed: Array is not sorted!"
    print(f"\nPrecondition holds: Array is sorted.")
    print(f"Searching for {x} in {A}")

    low = 0
    high = len(A) - 1
    iteration = 0

    while low <= high:
        iteration += 1
        mid = (low + high) // 2

        # Loop Invariant check
        print(f"\n[Iteration {iteration}]")
        print(f" low = {low}, high = {high}, mid = {mid}")
        print(f" A[mid] = {A[mid]}")

        if x in A:
            x_index = A.index(x)
            print(f" x = {x}, appears at index {x_index}")
            assert low <= x_index <= high, (
                "Invariant failed: x is in A but not in [low, high]"
            )
            print(" Invariant holds: x ∈ [low, high]")
        else:
            print(f" x = {x} is not in A")
            print(" Invariant trivially holds (x ∉ A)")

        # Binary search logic
        if A[mid] == x:
            print(f"\n Element found at index {mid}")
            return mid
        elif A[mid] < x:
            low = mid + 1
        else:
            high = mid - 1

    # Postcondition: if not found, x is not in the array
    assert x not in A, "Postcondition failed: x not found but is in A"
    print(f"\n Element not found, returning -1")
    print(f" Postcondition holds: x ∉ A")
    return -1


if __name__ == "__main__":
    A1 = [1, 3, 5, 7, 9, 11]
    binary_search_hoare(A1, 5)  # Should pass and find it

    A2 = [2, 4, 6, 8, 10]
    binary_search_hoare(A2, 7)  # Should fail to find but verify invariant
