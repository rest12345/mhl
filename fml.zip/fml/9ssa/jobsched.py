import random
import time

# -----------------------------
# Formal Specification:
# -----------------------------
# JOBS: finite set of jobs
# WORKERS: finite set of workers
# job_queue: jobs waiting to be assigned
# assigned: maps each worker to a job (or None)
# completed: set of completed jobs
# 
# Invariants:
#   1. Each job is assigned to at most one worker
#   2. All completed jobs must be from JOBS
#   3. No job is both assigned and completed
# -----------------------------

# Define job and worker pools
JOBS = {'J1', 'J2', 'J3', 'J4'}
WORKERS = {'W1', 'W2'}

# Initial state variables
job_queue = set(JOBS)
assigned = {w: None for w in WORKERS}
completed = set()

# -----------------------------
# Invariant Checks
# -----------------------------
def check_invariants():
    # 1. Each job is assigned to at most one worker
    assigned_jobs = list(filter(None, assigned.values()))
    if len(set(assigned_jobs)) != len(assigned_jobs):
        print(" Invariant Failed: A job is assigned to multiple workers!")
        return False

    # 2. Completed jobs are from the job set
    if not completed.issubset(JOBS):
        print(" Invariant Failed: Invalid job in completed set!")
        return False

    # 3. Assigned jobs should not be in completed
    for w, j in assigned.items():
        if j in completed:
            print(f" Invariant Failed: Job {j} is both assigned and completed!")
            return False

    return True

# -----------------------------
# Transition Functions
# -----------------------------
def assign_job(worker):
    if assigned[worker] is None and job_queue:
        job = random.choice(list(job_queue))
        assigned[worker] = job
        job_queue.remove(job)
        print(f" Assigned job {job} to worker {worker}")

def complete_job(worker):
    if assigned[worker] is not None:
        job = assigned[worker]
        assigned[worker] = None
        completed.add(job)
        print(f" Worker {worker} completed job {job}")

# -----------------------------
# Simulation Loop
# -----------------------------
def run_scheduler():
    step = 0
    while job_queue or any(assigned.values()):
        print(f"\n--- Step {step} ---")
        for worker in WORKERS:
            action = random.choice(['assign', 'complete'])
            if action == 'assign':
                assign_job(worker)
            else:
                complete_job(worker)

        # Invariant verification after each step
        if not check_invariants():
            print(" Halting simulation due to invariant violation.")
            return

        time.sleep(0.5)
        step += 1

    print("\n All jobs completed successfully!")
    print("Final State:")
    print(" Job Queue:", job_queue)
    print(" Assigned:", assigned)
    print(" Completed:", completed)

# -----------------------------
# Run Simulation
# -----------------------------
if __name__ == "__main__":
    run_scheduler()
