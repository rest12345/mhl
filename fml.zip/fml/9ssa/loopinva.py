def fixed_point_iteration(g, x0, tol=1e-5, max_iter=100):
    """
    Performs fixed-point iteration to solve x = g(x)
    
    Invariant: |x_n+1 - x_n| is decreasing or within tolerance
    Postcondition: Final approximation satisfies |g(x) - x| ≤ tol
    """
    print(f"Starting fixed-point iteration for g(x), x0 = {x0}")
    
    x_prev = x0
    iteration = 0
    converged = False

    while iteration < max_iter:
        x_next = g(x_prev)
        diff = abs(x_next - x_prev)

        print(f"\n[Iteration {iteration}]")
        print(f" x_prev = {x_prev}")
        print(f" x_next = {x_next}")
        print(f" |x_next - x_prev| = {diff}")

        # Loop invariant check: difference should be decreasing or below tolerance
        if iteration > 0:
            assert diff <= prev_diff + 1e-10, (
                "Invariant failed: Difference increased!"
            )
            print(" Invariant holds: Difference is decreasing")

        if diff <= tol:
            print(f"\n Converged to fixed point at x = {x_next}")
            converged = True
            break

        prev_diff = diff
        x_prev = x_next
        iteration += 1

    # Postcondition: convergence within tolerance
    if converged:
        assert abs(g(x_next) - x_next) <= tol, "Postcondition failed: Not a fixed point"
        print(" Postcondition holds: g(x) ≈ x")
    else:
        print("\n Did not converge within max_iter")


# Example usage
import math

# Define g(x) = cos(x) ⇒ has a fixed point near 0.739...
g = lambda x: math.cos(x)
fixed_point_iteration(g, x0=1.0)
