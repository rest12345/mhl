class Graph:
    def __init__(self, n):
        self.n = n
        self.adj = {i: [] for i in range(n)}

    def add_edge(self, u, v):
        self.adj[u].append(v)

# -------------------------------
# Topological Sort using DFS
# -------------------------------
def dfs_topo_sort(graph):
    visited = [False] * graph.n
    stack = []

    def dfs(u):
        visited[u] = True
        for v in graph.adj[u]:
            if not visited[v]:
                dfs(v)
        stack.append(u)

    for u in range(graph.n):
        if not visited[u]:
            dfs(u)

    return stack[::-1]  # Reverse for topological order

# -------------------------------
# Validate Topological Sort Order
# -------------------------------
def is_valid_topo_sort(graph, topo_order):
    pos = {node: idx for idx, node in enumerate(topo_order)}
    for u in range(graph.n):
        for v in graph.adj[u]:
            if pos[u] >= pos[v]:  # u should come before v
                return False
    return True

# -------------------------------
# Model Checking the Topo Sort
# -------------------------------
def model_check_topo_sort(graph):
    print("Model checking topological sort...")
    result = dfs_topo_sort(graph)
    print("Topological Sort Result:", result)

    # Check if all nodes are included
    if sorted(result) != list(range(graph.n)):
        print(" ❌ Sort does not include all nodes.")
        return False

    # Validate the topological order
    if not is_valid_topo_sort(graph, result):
        print(" ❌ Topological sort violates dependency order.")
        return False

    print(" ✅ Model check passed: Topological sort is valid.")
    return True

# -------------------------------
# Main Execution
# -------------------------------
if __name__ == "__main__":
    g = Graph(6)
    g.add_edge(5, 2)
    g.add_edge(5, 0)
    g.add_edge(4, 0)
    g.add_edge(4, 1)
    g.add_edge(2, 3)
    g.add_edge(3, 1)

    model_check_topo_sort(g)
