import threading
import queue
import time

# Shared control channel to send dynamically created channels
control_channel = queue.Queue()

def process_A():
    print("[A] Creating private channel...")
    private_channel = queue.Queue()

    print("[A] Sending channel to B via control channel")
    control_channel.put(private_channel)  # Send channel to B

    time.sleep(1)  # Wait for B to be ready

    print("[A] Sending message: 'hello'")
    private_channel.put("hello")

def process_B():
    print("[B] Waiting to receive channel from A...")
    received_channel = control_channel.get()

    print("[B] Channel received. Waiting for message...")
    msg = received_channel.get()
    print(f"[B] Message received from A: '{msg}'")

# Create and start both threads
thread_a = threading.Thread(target=process_A)
thread_b = threading.Thread(target=process_B)

thread_a.start()
thread_b.start()

thread_a.join()
thread_b.join()
