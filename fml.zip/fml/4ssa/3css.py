import queue
import threading
import time

# Shared channels (queues) for process communication
channels = {
    "a": queue.Queue(),
    "b": queue.Queue()
}

# Relabeling map (e.g., a → b)
relabel_map = {
    "a": "b"
}

# Restriction set (actions to hide)
restricted_actions = {"b"}

def relabel(action):
    return relabel_map.get(action, action)

def is_visible(action):
    return action not in restricted_actions

def process(name, actions):
    for action in actions:
        actual_action = relabel(action)
        if is_visible(actual_action):
            print(f"[{name}] Performing visible action: {actual_action}")
        else:
            print(f"[{name}] Performing restricted action: {actual_action} (hidden)")

        # Simulate communication/synchronization on that action
        if actual_action in channels:
            channels[actual_action].put(f"{name}-{actual_action}")
            time.sleep(0.5)
            channels[actual_action].get()

# Process definitions
P1 = threading.Thread(target=process, args=("P1", ["a", "c"]))
P2 = threading.Thread(target=process, args=("P2", ["a", "d"]))
P3 = threading.Thread(target=process, args=("P3", ["b", "e"]))

# Start all in parallel
P1.start()
P2.start()
P3.start()

P1.join()
P2.join()
P3.join()
