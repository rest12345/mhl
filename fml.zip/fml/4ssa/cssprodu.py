import threading
import queue
import time
import random

# Shared buffer with size 1 to simulate tight synchronization
buffer = queue.Queue(maxsize=1)

def producer():
    for i in range(5):
        item = f"item-{i}"
        print(f"[Producer] Producing {item}")
        buffer.put(item)  # Simulates CCS 'put' action
        print(f"[Producer] Sent {item}")
        time.sleep(random.uniform(0.5, 1.0))

    buffer.put("DONE")  # Signal termination

def consumer():
    while True:
        item = buffer.get()  # Simulates CCS 'get' action
        if item == "DONE":
            print("[Consumer] Terminating.")
            break
        print(f"[Consumer] Consumed {item}")
        time.sleep(random.uniform(0.5, 1.0))

# Run both in parallel (CCS parallel composition: P | Q)
prod_thread = threading.Thread(target=producer)
cons_thread = threading.Thread(target=consumer)

prod_thread.start()
cons_thread.start()

prod_thread.join()
cons_thread.join()
