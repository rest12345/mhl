import threading
import queue
import time
import random

# Queues for clients to dispatcher
request_queue = queue.Queue()

# Queues for dispatcher to workers
worker_queues = [queue.Queue(), queue.Queue()]

NUM_CLIENTS = 3
NUM_WORKERS = 2

def client(cid):
    for i in range(2):  # Each client sends 2 requests
        request = f"Client-{cid}-Req-{i}"
        print(f"[Client-{cid}] Sending: {request}")
        request_queue.put(request)
        time.sleep(random.uniform(0.5, 1.0))

def dispatcher():
    count = 0
    while True:
        request = request_queue.get()
        if request == "DONE":
            break
        worker_id = count % NUM_WORKERS
        print(f"[Dispatcher] Forwarding '{request}' to Worker-{worker_id}")
        worker_queues[worker_id].put(request)
        count += 1

    # Signal workers to stop
    for q in worker_queues:
        q.put("DONE")

def worker(wid):
    while True:
        task = worker_queues[wid].get()
        if task == "DONE":
            print(f"[Worker-{wid}] Shutting down.")
            break
        print(f"[Worker-{wid}] Processing {task}")
        time.sleep(random.uniform(0.5, 1.0))

# Start threads
client_threads = [threading.Thread(target=client, args=(i,)) for i in range(NUM_CLIENTS)]
dispatcher_thread = threading.Thread(target=dispatcher)
worker_threads = [threading.Thread(target=worker, args=(i,)) for i in range(NUM_WORKERS)]

for t in worker_threads + [dispatcher_thread] + client_threads:
    t.start()

# Wait for clients to finish
for t in client_threads:
    t.join()

# Tell dispatcher to stop
request_queue.put("DONE")
dispatcher_thread.join()

# Wait for workers
for t in worker_threads:
    t.join()
