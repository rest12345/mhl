from collections import defaultdict

class Process:
    def __init__(self, name):
        self.name = name
        self.transitions = defaultdict(list)  # action -> list of target state names

    def add_transition(self, action, target):
        self.transitions[action].append(target)

# Define the transition systems for P and Q
processes = {}

def define_process(name, transitions):
    proc = Process(name)
    for action, target in transitions:
        proc.add_transition(action, target)
    processes[name] = proc

# Example: Process P
define_process("P", [("a", "P1"), ("b", "P2")])
define_process("P1", [])
define_process("P2", [])

# Example: Process Q
define_process("Q", [("a", "Q1"), ("b", "Q2")])
define_process("Q1", [])
define_process("Q2", [])

# Strong bisimulation checker
def is_bisimilar(p1, p2, visited=set()):
    if (p1, p2) in visited:
        return True
    visited.add((p1, p2))

    proc1 = processes[p1]
    proc2 = processes[p2]

    # For every action in proc1, ensure proc2 can do same
    for action in proc1.transitions:
        targets1 = proc1.transitions[action]
        targets2 = proc2.transitions.get(action, [])
        if len(targets1) != len(targets2):
            return False
        for t1, t2 in zip(targets1, targets2):
            if not is_bisimilar(t1, t2, visited):
                return False

    # Repeat for proc2 -> proc1
    for action in proc2.transitions:
        targets1 = proc1.transitions.get(action, [])
        targets2 = proc2.transitions[action]
        if len(targets1) != len(targets2):
            return False
        for t1, t2 in zip(targets1, targets2):
            if not is_bisimilar(t1, t2, visited):
                return False

    return True

# Run checker
result = is_bisimilar("P", "Q")
print(f"Processes P and Q are strongly bisimilar: {result}")
