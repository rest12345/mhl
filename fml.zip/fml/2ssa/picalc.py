import threading
import queue

# Shared channel (as a Queue)
channel = queue.Queue()

# Sender Process
def sender(channel, message):
    print(f"Sender: Sending '{message}' on channel 'a'")
    channel.put(message)
    print("Sender: Done")

# Receiver Process
def receiver(channel):
    print("Receiver: Waiting to receive on channel 'a'")
    message = channel.get()  # Waits until a message is available
    print(f"Receiver: Received '{message}' from channel 'a'")
    print("Receiver: Done")

# Create threads for sender and receiver
sender_thread = threading.Thread(target=sender, args=(channel, "HelloPi"))
receiver_thread = threading.Thread(target=receiver, args=(channel,))

# Start both
receiver_thread.start()
sender_thread.start()

# Wait for both to complete
sender_thread.join()
receiver_thread.join()
