import threading
import time

class CCSProcess(threading.Thread):
    def __init__(self, name, actions):
        super().__init__()
        self.name = name
        self.actions = actions

    def run(self):
        for action in self.actions:
            print(f"Process {self.name}: Performing action '{action}'")
            time.sleep(0.5)  # Simulate delay between actions

# Define two processes with their action sequences
P = CCSProcess("P", ["a", "b"])
Q = CCSProcess("Q", ["x", "y"])

# Simulate parallel execution
P.start()
Q.start()

# Wait for both processes to complete
P.join()
Q.join()
