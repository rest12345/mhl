class CCSProcess:
    def __init__(self, name, action=None, next_process=None):
        self.name = name
        self.action = action
        self.next_process = next_process

    def perform_action(self):
        if self.action:
            print(f"Process {self.name}: Performing action '{self.action}'")
            return self.next_process
        else:
            print(f"Process {self.name}: No action to perform")
            return None

# Define processes
Q = CCSProcess("Q")
P = CCSProcess("P", action='a', next_process=Q)

# Simulate process transition
current_process = P
while current_process:
    current_process = current_process.perform_action()
