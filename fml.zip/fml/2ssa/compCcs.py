import threading

# Lock to simulate synchronization
sync_lock = threading.Lock()
sync_event = threading.Event()

def process_a():
    print("Process A: Ready to perform action 'a'")
    with sync_lock:
        sync_event.set()  # Signal that 'a' is ready
        print("Process A: Waiting for 'ā' to synchronize...")
        sync_event.wait()  # Wait for 'ā' to be ready
    print("Process A: Synchronized with 'ā' → τ (silent action)")

def process_a_bar():
    print("Process B: Ready to perform action 'ā'")
    sync_event.wait()  # Wait for 'a' to be ready
    with sync_lock:
        print("Process B: Synchronized with 'a' → τ (silent action)")
        sync_event.set()  # Unblock 'a'

# Create threads for both processes
thread_a = threading.Thread(target=process_a)
thread_a_bar = threading.Thread(target=process_a_bar)

# Start both
thread_a.start()
thread_a_bar.start()

# Wait for both to complete
thread_a.join()
thread_a_bar.join()
