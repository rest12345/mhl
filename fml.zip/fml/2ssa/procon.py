import threading
import queue
import time
import random

buffer = queue.Queue(maxsize=5)  # Shared bounded buffer

# Producer
def producer():
    for i in range(10):
        item = f"Item-{i}"
        buffer.put(item)  # Blocks if buffer is full
        print(f"Producer: Produced {item}")
        time.sleep(random.uniform(0.1, 0.5))  # Simulate variable production time

# Consumer
def consumer():
    for i in range(10):
        item = buffer.get()  # Blocks if buffer is empty
        print(f"Consumer: Consumed {item}")
        time.sleep(random.uniform(0.1, 0.5))  # Simulate variable consumption time

# Create threads
producer_thread = threading.Thread(target=producer)
consumer_thread = threading.Thread(target=consumer)

# Start threads
producer_thread.start()
consumer_thread.start()

# Wait for threads to complete
producer_thread.join()
consumer_thread.join()
