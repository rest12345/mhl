import re

# -------------------------------
# Lexer: Tokenize Input using Regex (Finite Automata)
# -------------------------------
token_specification = [
    ('NUMBER', r'\d+'),
    ('ID', r'[a-zA-Z_]\w*'),
    ('PLUS', r'\+'),
    ('MINUS', r'-'),
    ('TIMES', r'\*'),
    ('DIVIDE', r'/'),
    ('LPAREN', r'\('),
    ('RPAREN', r'\)'),
    ('EQUAL', r'='),
    ('SKIP', r'[ \t]+'),  # Skip spaces/tabs
    ('MISMATCH', r'.'),   # Any other character
]

token_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_specification)

def tokenize(code):
    tokens = []
    for mo in re.finditer(token_regex, code):
        kind = mo.lastgroup
        value = mo.group()
        if kind == 'NUMBER':
            tokens.append(('NUMBER', int(value)))
        elif kind == 'ID':
            tokens.append(('ID', value))
        elif kind == 'SKIP':
            continue
        elif kind == 'MISMATCH':
            raise SyntaxError(f"Illegal character {value}")
        else:
            tokens.append((kind, value))
    return tokens

# -------------------------------
# Parser: Recursive Descent (CFG parsing)
# Grammar:
#   stmt   → ID '=' expr | expr
#   expr   → term ((PLUS | MINUS) term)*
#   term   → factor ((TIMES | DIVIDE) factor)*
#   factor → NUMBER | ID | '(' expr ')'
# -------------------------------
class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else ('EOF', None)

    def match(self, expected_type):
        if self.peek()[0] == expected_type:
            self.pos += 1
        else:
            raise SyntaxError(f"Expected {expected_type} at position {self.pos}")

    def parse(self):
        if self.peek()[0] == 'ID' and self.tokens[self.pos + 1][0] == 'EQUAL':
            self.match('ID')
            self.match('EQUAL')
            self.expr()
        else:
            self.expr()

        if self.peek()[0] != 'EOF':
            raise SyntaxError("Unexpected token after expression")

    def expr(self):
        self.term()
        while self.peek()[0] in ('PLUS', 'MINUS'):
            self.match(self.peek()[0])
            self.term()

    def term(self):
        self.factor()
        while self.peek()[0] in ('TIMES', 'DIVIDE'):
            self.match(self.peek()[0])
            self.factor()

    def factor(self):
        token_type, _ = self.peek()
        if token_type == 'NUMBER':
            self.match('NUMBER')
        elif token_type == 'ID':
            self.match('ID')
        elif token_type == 'LPAREN':
            self.match('LPAREN')
            self.expr()
            self.match('RPAREN')
        else:
            raise SyntaxError(f"Unexpected token {token_type}")

# -------------------------------
# Evaluator: Execution with Variable Storage
# -------------------------------
class Evaluator:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0
        self.variables = {}

    def peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else ('EOF', None)

    def match(self, expected_type):
        if self.peek()[0] == expected_type:
            self.pos += 1
        else:
            raise SyntaxError(f"Expected {expected_type} at position {self.pos}")

    def parse(self):
        if self.peek()[0] == 'ID' and self.tokens[self.pos + 1][0] == 'EQUAL':
            var_name = self.tokens[self.pos][1]
            self.match('ID')
            self.match('EQUAL')
            value = self.expr()
            self.variables[var_name] = value
            return f"{var_name} = {value}"
        else:
            return self.expr()

    def expr(self):
        result = self.term()
        while self.peek()[0] in ('PLUS', 'MINUS'):
            op = self.peek()[0]
            self.match(op)
            right = self.term()
            result = result + right if op == 'PLUS' else result - right
        return result

    def term(self):
        result = self.factor()
        while self.peek()[0] in ('TIMES', 'DIVIDE'):
            op = self.peek()[0]
            self.match(op)
            right = self.factor()
            result = result * right if op == 'TIMES' else result // right
        return result

    def factor(self):
        token_type, value = self.peek()
        if token_type == 'NUMBER':
            self.match('NUMBER')
            return value
        elif token_type == 'ID':
            self.match('ID')
            return self.variables.get(value, 0)
        elif token_type == 'LPAREN':
            self.match('LPAREN')
            result = self.expr()
            self.match('RPAREN')
            return result
        else:
            raise SyntaxError(f"Unexpected token {token_type}")

# -------------------------------
# Main Driver
# -------------------------------
if __name__ == "__main__":
    code = "x = 3 + 4 * (2 - 1)"
    print("Input code:", code)
    
    try:
        tokens = tokenize(code)
        print("Tokens:", tokens)

        evaluator = Evaluator(tokens)
        result = evaluator.parse()
        print("Result:", result)

    except SyntaxError as e:
        print("Syntax error:", e)
