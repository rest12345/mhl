from collections import defaultdict, deque
from typing import Set, Dict, Tuple
from graphviz import Digraph

# -------------------------
# NFA Class
# -------------------------
class NFA:
    def __init__(self, states: Set[str], alphabet: Set[str], transitions: Dict[Tuple[str, str], Set[str]],
                 start_state: str, accept_states: Set[str]):
        self.states = states
        self.alphabet = alphabet
        self.transitions = transitions
        self.start_state = start_state
        self.accept_states = accept_states

    def epsilon_closure(self, states: Set[str]) -> Set[str]:
        stack = list(states)
        closure = set(states)
        while stack:
            state = stack.pop()
            for next_state in self.transitions.get((state, ''), set()):  # ε-transition
                if next_state not in closure:
                    closure.add(next_state)
                    stack.append(next_state)
        return closure

    def move(self, states: Set[str], symbol: str) -> Set[str]:
        result = set()
        for state in states:
            result.update(self.transitions.get((state, symbol), set()))
        return result

    def accepts(self, input_string: str) -> bool:
        current_states = self.epsilon_closure({self.start_state})
        for symbol in input_string:
            current_states = self.epsilon_closure(self.move(current_states, symbol))
        return bool(current_states & self.accept_states)

# -------------------------
# DFA Class
# -------------------------
class DFA:
    def __init__(self):
        self.states = set()
        self.alphabet = set()
        self.transitions = {}
        self.start_state = ''
        self.accept_states = set()

    def accepts(self, input_string: str) -> bool:
        state = self.start_state
        for symbol in input_string:
            state = self.transitions.get((state, symbol))
            if state is None:
                return False
        return state in self.accept_states

# -------------------------
# NFA to DFA Conversion
# -------------------------
def nfa_to_dfa(nfa: NFA) -> DFA:
    dfa = DFA()
    dfa.alphabet = nfa.alphabet - {''}
    start_closure = frozenset(nfa.epsilon_closure({nfa.start_state}))
    state_map = {start_closure: 'Q0'}
    dfa.start_state = 'Q0'
    dfa.states.add('Q0')
    queue = deque([start_closure])
    state_id = 1

    while queue:
        current = queue.popleft()
        current_label = state_map[current]
        for symbol in dfa.alphabet:
            move_result = nfa.move(current, symbol)
            closure = frozenset(nfa.epsilon_closure(move_result))
            if closure not in state_map:
                label = f"Q{state_id}"
                state_map[closure] = label
                dfa.states.add(label)
                queue.append(closure)
                state_id += 1
            dfa.transitions[(current_label, symbol)] = state_map[closure]

    for state_set, label in state_map.items():
        if state_set & nfa.accept_states:
            dfa.accept_states.add(label)
    return dfa

# -------------------------
# Visualization (Optional)
# -------------------------
def visualize_automaton(transitions, start_state, accept_states, title="Automaton"):
    dot = Digraph(name=title)
    dot.attr(rankdir='LR')
    dot.node('', shape='none')
    all_states = set(s for s, _ in transitions.keys()) | set().union(*transitions.values())
    for state in all_states:
        dot.node(state, shape='doublecircle' if state in accept_states else 'circle')
    dot.edge('', start_state)
    for (src, symbol), targets in transitions.items():
        for tgt in targets:
            dot.edge(src, tgt, label=symbol if symbol else "ε")
    return dot

# -------------------------
# Simulation Runner
# -------------------------
def run_simulation():
    # Define an NFA that accepts strings ending in "ab"
    states = {"q0", "q1", "q2"}
    alphabet = {"a", "b"}
    transitions = {
        ("q0", "a"): {"q0", "q1"},
        ("q0", "b"): {"q0"},
        ("q1", "b"): {"q2"}
    }
    start_state = "q0"
    accept_states = {"q2"}

    # Create NFA
    nfa = NFA(states, alphabet, transitions, start_state, accept_states)

    # Convert to DFA
    dfa = nfa_to_dfa(nfa)

    # Test input strings
    test_strings = ["", "a", "ab", "aab", "abb", "babab", "aabb"]

    print("String\tNFA\tDFA")
    for s in test_strings:
        result_nfa = nfa.accepts(s)
        result_dfa = dfa.accepts(s)
        print(f"{s!r:6}\t{'✔' if result_nfa else '✘'}\t{'✔' if result_dfa else '✘'}")

    # Equivalence check
    equivalent = all(nfa.accepts(s) == dfa.accepts(s) for s in test_strings)
    print(f"\n✅ NFA and DFA are equivalent on test set: {equivalent}")

    # Optional: Visualize
    visualize_automaton(transitions, start_state, accept_states, "NFA").render("nfa", view=False, format='png')
    visualize_automaton(dfa.transitions, dfa.start_state, dfa.accept_states, "DFA").render("dfa", view=False, format='png')
    print("Visualizations saved as 'nfa.png' and 'dfa.png'.")

# -------------------------
# Main Entry Point
# -------------------------
if __name__ == "__main__":
    run_simulation()
