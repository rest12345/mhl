class DFA:
    def __init__(self, states, alphabet, transition, start_state, accept_states):
        self.states = states
        self.alphabet = alphabet
        self.transition = transition  # {(state, symbol): next_state}
        self.start_state = start_state
        self.accept_states = accept_states


def minimize_dfa(dfa):
    # Initial partition: final and non-final states
    P = [set(dfa.accept_states), set(dfa.states) - set(dfa.accept_states)]
    W = [set(dfa.accept_states)]

    def get_partition_index(state, partitions):
        for idx, part in enumerate(partitions):
            if state in part:
                return idx
        return None

    while W:
        A = W.pop()
        for c in dfa.alphabet:
            pre_image = set()
            for (s, sym), dest in dfa.transition.items():
                if sym == c and dest in A:
                    pre_image.add(s)

            new_P = []
            for Y in P:
                intersect = Y & pre_image
                diff = Y - pre_image
                if intersect and diff:
                    new_P.append(intersect)
                    new_P.append(diff)
                    if Y in W:
                        W.remove(Y)
                        W.extend([intersect, diff])
                    else:
                        W.append(intersect if len(intersect) <= len(diff) else diff)
                else:
                    new_P.append(Y)
            P = new_P

    # Build minimized DFA
    state_map = {s: idx for idx, group in enumerate(P) for s in group}
    new_states = set(state_map.values())
    new_start = state_map[dfa.start_state]
    new_accept = {state_map[s] for s in dfa.accept_states}
    new_trans = {}
    for (s, sym), dest in dfa.transition.items():
        new_trans[(state_map[s], sym)] = state_map[dest]

    return DFA(new_states, dfa.alphabet, new_trans, new_start, new_accept)


def are_equivalent(dfa1, dfa2):
    from collections import deque

    visited = set()
    queue = deque([(dfa1.start_state, dfa2.start_state)])

    while queue:
        s1, s2 = queue.popleft()
        if (s1 in dfa1.accept_states) != (s2 in dfa2.accept_states):
            return False
        if (s1, s2) in visited:
            continue
        visited.add((s1, s2))
        for sym in dfa1.alphabet:
            next1 = dfa1.transition.get((s1, sym))
            next2 = dfa2.transition.get((s2, sym))
            if next1 is None or next2 is None:
                continue
            queue.append((next1, next2))
    return True


if __name__ == "__main__":
    # DFA 1: accepts even number of 0s
    states1 = {0, 1}
    trans1 = {
        (0, '0'): 1, (1, '0'): 0,
        (0, '1'): 0, (1, '1'): 1
    }
    dfa1 = DFA(states1, {'0', '1'}, trans1, 0, {0})

    # DFA 2: same as DFA 1
    states2 = {0, 1}
    trans2 = {
        (0, '0'): 1, (1, '0'): 0,
        (0, '1'): 0, (1, '1'): 1
    }
    dfa2 = DFA(states2, {'0', '1'}, trans2, 0, {0})

    minimized1 = minimize_dfa(dfa1)
    minimized2 = minimize_dfa(dfa2)

    print("DFA 1 and DFA 2 are equivalent?", are_equivalent(minimized1, minimized2))
