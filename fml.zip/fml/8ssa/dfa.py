class DFA:
    def __init__(self, states, alphabet, transition, start_state, accepting_states):
        self.states = states
        self.alphabet = alphabet
        self.transition = transition
        self.start_state = start_state
        self.accepting_states = accepting_states

    def is_accepted(self, input_string):
        state = self.start_state
        for symbol in input_string:
            if symbol not in self.alphabet:
                print(f"Invalid symbol: {symbol}")
                return False
            state = self.transition[state][symbol]
        return state in self.accepting_states


# Define DFA for strings that accept only binary strings ending with '01'
states = {'q0', 'q1', 'q2'}
alphabet = {'0', '1'}
transition = {
    'q0': {'0': 'q0', '1': 'q1'},
    'q1': {'0': 'q2', '1': 'q1'},
    'q2': {'0': 'q0', '1': 'q1'}
}
start_state = 'q0'
accepting_states = {'q2'}

dfa = DFA(states, alphabet, transition, start_state, accepting_states)

# Test the DFA with strings
test_strings = ["101", "1001", "0101", "111"]
for s in test_strings:
    result = "Accepted" if dfa.is_accepted(s) else "Rejected"
    print(f"String: {s} -> {result}")
