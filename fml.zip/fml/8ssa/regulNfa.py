# -------------------------------
# Convert Regex to Postfix (Shunting Yard Algorithm)
# -------------------------------
def regex_to_postfix(regex):
    precedence = {'*': 3, '.': 2, '|': 1}
    output = []
    stack = []

    def add_concat_operators(regex):
        result = ''
        for i in range(len(regex)):
            result += regex[i]
            if i + 1 < len(regex):
                if regex[i] not in '(|' and regex[i+1] not in '|)*':
                    result += '.'
        return result

    regex = add_concat_operators(regex)

    for char in regex:
        if char.isalnum():
            output.append(char)
        elif char == '(':
            stack.append(char)
        elif char == ')':
            while stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()
        else:
            while (stack and stack[-1] != '(' and
                   precedence.get(stack[-1], 0) >= precedence[char]):
                output.append(stack.pop())
            stack.append(char)

    while stack:
        output.append(stack.pop())

    return ''.join(output)

# -------------------------------
# NFA Components
# -------------------------------
class State:
    def __init__(self):
        self.transitions = {}  # symbol → set of next states

    def add_transition(self, symbol, state):
        if symbol in self.transitions:
            self.transitions[symbol].add(state)
        else:
            self.transitions[symbol] = {state}

class Fragment:
    def __init__(self, start, accept):
        self.start = start
        self.accept = accept

# -------------------------------
# Convert Postfix Regex to ε-NFA
# -------------------------------
def postfix_to_nfa(postfix):
    stack = []
    for char in postfix:
        if char.isalnum():
            s1, s2 = State(), State()
            s1.add_transition(char, s2)
            stack.append(Fragment(s1, s2))
        elif char == '*':
            frag = stack.pop()
            s_start, s_accept = State(), State()
            s_start.add_transition('', frag.start)
            s_start.add_transition('', s_accept)
            frag.accept.add_transition('', frag.start)
            frag.accept.add_transition('', s_accept)
            stack.append(Fragment(s_start, s_accept))
        elif char == '.':
            frag2 = stack.pop()
            frag1 = stack.pop()
            frag1.accept.add_transition('', frag2.start)
            stack.append(Fragment(frag1.start, frag2.accept))
        elif char == '|':
            frag2 = stack.pop()
            frag1 = stack.pop()
            s_start, s_accept = State(), State()
            s_start.add_transition('', frag1.start)
            s_start.add_transition('', frag2.start)
            frag1.accept.add_transition('', s_accept)
            frag2.accept.add_transition('', s_accept)
            stack.append(Fragment(s_start, s_accept))
    return stack.pop()

# -------------------------------
# NFA Simulation Utilities
# -------------------------------
def epsilon_closure(states):
    stack = list(states)
    closure = set(states)
    while stack:
        state = stack.pop()
        for next_state in state.transitions.get('', []):
            if next_state not in closure:
                closure.add(next_state)
                stack.append(next_state)
    return closure

def move(states, symbol):
    result = set()
    for state in states:
        result.update(state.transitions.get(symbol, []))
    return result

def simulate_nfa(nfa, input_string):
    current_states = epsilon_closure({nfa.start})
    for symbol in input_string:
        current_states = epsilon_closure(move(current_states, symbol))
    return nfa.accept in current_states

# -------------------------------
# Main Entry: Test Tool
# -------------------------------
if __name__ == "__main__":
    regex = "a(b|c)*"
    postfix = regex_to_postfix(regex)
    print("Infix Regex: ", regex)
    print("Postfix Expression: ", postfix)

    nfa_frag = postfix_to_nfa(postfix)

    test_strings = ["a", "ab", "ac", "abc", "abcc", "b", "c", "aa"]
    print("\nString Matching Results:")
    for s in test_strings:
        result = simulate_nfa(nfa_frag, s)
        print(f"Input: {s!r} → {'ACCEPTED' if result else 'REJECTED'}")
