class Process:
    def __init__(self, name, transitions):
        """
        transitions: Dict where key is action and value is the next Process
        """
        self.name = name
        self.transitions = transitions  # Dict[action] = next_process

    def get_actions(self):
        return set(self.transitions.keys())

    def next_state(self, action):
        return self.transitions.get(action)

def strong_bisimilar(p1, p2, visited=None):
    if visited is None:
        visited = set()

    key = (id(p1), id(p2))
    if key in visited:
        return True  # Already compared

    visited.add(key)

    if p1.get_actions() != p2.get_actions():
        return False

    for action in p1.get_actions():
        next1 = p1.next_state(action)
        next2 = p2.next_state(action)
        if not next1 or not next2:
            return False
        if not strong_bisimilar(next1, next2, visited):
            return False

    return True

# Define process P = a.b.0
P0 = Process("P0", {})
P1 = Process("P1", {"b": P0})
P = Process("P", {"a": P1})

# Define process Q = a.b.0
Q0 = Process("Q0", {})
Q1 = Process("Q1", {"b": Q0})
Q = Process("Q", {"a": Q1})

# Test bisimulation
print("Are P and Q strongly bisimilar?", strong_bisimilar(P, Q))
