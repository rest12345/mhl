import threading
import queue
import time

# Shared communication channel
channel = queue.Queue()

# Server Process
def server():
    print("Server: Waiting for 'req'")
    req = channel.get()  # waits for request
    if req == 'req':
        print("Server: Received 'req', processing...")
        time.sleep(1)
        channel.put('res')
        print("Server: Sent 'res'")

# Client Process
def client():
    print("Client: Sending 'req'")
    channel.put('req')
    print("Client: Waiting for 'res'")
    res = channel.get()
    if res == 'res':
        print("Client: Received 'res'")

# Run server and client
server_thread = threading.Thread(target=server)
client_thread = threading.Thread(target=client)

# Start both processes
server_thread.start()
client_thread.start()

# Wait for completion
server_thread.join()
client_thread.join()
