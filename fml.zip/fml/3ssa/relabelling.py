class Process:
    def __init__(self, name, actions):
        self.name = name
        self.actions = actions  # List of actions like ['a', 'b']

    def relabel(self, relabel_map):
        """Applies relabeling: e.g., {'a': 'b'}"""
        self.actions = [relabel_map.get(act, act) for act in self.actions]

    def restrict(self, restricted):
        """Hides actions by replacing them with τ (tau)"""
        self.actions = ['τ' if act in restricted else act for act in self.actions]

    def trace(self):
        """Returns the action trace"""
        return self.actions

def are_bisimilar(p1, p2):
    """Checks strong bisimulation based on action traces"""
    return p1.trace() == p2.trace()

# Define processes
P = Process("P", ["a"])
Q = Process("Q", ["b"])

# Apply relabeling to P
P_relabel = Process("P'", P.actions.copy())
P_relabel.relabel({'a': 'b'})  # P becomes b.0

# Apply restriction to original P (hide 'a')
P_restrict = Process("P_restrict", ["a"])
P_restrict.restrict({'a'})  # becomes τ.0

# Output traces
print(f"P after relabeling: {P_relabel.trace()} (should match Q)")
print(f"Q trace: {Q.trace()}")
print("Are P' and Q strongly bisimilar?", are_bisimilar(P_relabel, Q))

print(f"P after restriction: {P_restrict.trace()}")
