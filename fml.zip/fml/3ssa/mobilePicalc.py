import threading
import queue
import time

# Control channel to send the dynamically created channel
control_channel = queue.Queue()

def child_process():
    print("Child: Waiting to receive channel from parent...")
    new_channel = control_channel.get()  # Receive dynamically created channel
    print("Child: Received new channel")
    
    msg = new_channel.get()  # Receive message on the new channel
    print(f"Child: Received message → {msg}")

def parent_process():
    print("Parent: Creating new private channel...")
    new_channel = queue.Queue()

    print("Parent: Sending new channel to child")
    control_channel.put(new_channel)  # Send the new channel to the child

    time.sleep(1)  # Give time for child to be ready

    print("Parent: Sending message over new channel")
    new_channel.put("Hello from parent")

# Launch both processes
child_thread = threading.Thread(target=child_process)
parent_thread = threading.Thread(target=parent_process)

child_thread.start()
parent_thread.start()

child_thread.join()
parent_thread.join()
