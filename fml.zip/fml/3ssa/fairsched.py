import threading
import time

# Shared lock to protect the resource
resource_lock = threading.Lock()

# Scheduler control
scheduler_event = threading.Event()
turn = "P"  # Start with process P
turn_lock = threading.Lock()

def process(name, actions):
    global turn
    for action in actions:
        time.sleep(0.5)  # Simulate delay before requesting
        while True:
            with turn_lock:
                if turn == name:
                    break
            time.sleep(0.1)  # Busy wait until it's their turn

        print(f"{name}: Action → {action} (requesting resource)")
        with resource_lock:
            print(f"{name}: Using resource")
            time.sleep(1)  # Simulate resource usage
            print(f"{name}: Done using resource")

        # Switch turn to the other process
        with turn_lock:
            turn = "Q" if name == "P" else "P"

# Define process action traces
P_actions = ["reqP", "useP", "reqP", "useP"]
Q_actions = ["reqQ", "useQ", "reqQ", "useQ"]

# Launch both processes
thread_P = threading.Thread(target=process, args=("P", P_actions))
thread_Q = threading.Thread(target=process, args=("Q", Q_actions))

thread_P.start()
thread_Q.start()

thread_P.join()
thread_Q.join()
