from snakes.nets import *

# Create Petri Net
net = PetriNet('OrderProcessing')

# Add places (order stages)
net.add_place(Place('OrderPlaced', ['waiting']))   # Waiting for processing
net.add_place(Place('PaymentProcessed', ['not_done']))
net.add_place(Place('OrderShipped', ['not_done']))
net.add_place(Place('OrderDelivered', ['not_done']))

# Add transitions (steps in workflow)
net.add_transition(Transition('ProcessPayment'))
net.add_input('OrderPlaced', 'ProcessPayment', Value('waiting'))
net.add_output('PaymentProcessed', 'ProcessPayment', Value('done'))

net.add_transition(Transition('ShipOrder'))
net.add_input('PaymentProcessed', 'ShipOrder', Value('done'))
net.add_output('OrderShipped', 'ShipOrder', Value('shipped'))

net.add_transition(Transition('DeliverOrder'))
net.add_input('OrderShipped', 'DeliverOrder', Value('shipped'))
net.add_output('OrderDelivered', 'DeliverOrder', Value('delivered'))

# Check deadlock freedom
def check_deadlock(net):
    enabled_transitions = [t.name for t in net.transitions() if net.transition(t.name).enabled()]
    return len(enabled_transitions) == 0

# Simulate the order processing workflow
print("Before firing any transition:")
print(f"Is deadlocked? {check_deadlock(net)}")

if net.transition('ProcessPayment').enabled():
    net.transition('ProcessPayment').fire(Substitution())
    print("Payment processed.")

if net.transition('ShipOrder').enabled():
    net.transition('ShipOrder').fire(Substitution())
    print("Order shipped.")

if net.transition('DeliverOrder').enabled():
    net.transition('DeliverOrder').fire(Substitution())
    print("Order delivered.")

print(f"Is deadlocked after processing? {check_deadlock(net)}")
