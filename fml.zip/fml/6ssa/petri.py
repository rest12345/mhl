# pip install snakes
from snakes.nets import * 

# Create Petri Net
net = PetriNet('DiningPhilosophers')

# Add places (forks and philosophers)
net.add_place(Place('Fork1', ['free']))
net.add_place(Place('Fork2', ['free']))
net.add_place(Place('Philosopher1', ['hungry']))
net.add_place(Place('Philosopher2', ['hungry']))

# Add transitions
net.add_transition(Transition('P1_Eats'))
net.add_input('Philosopher1', 'P1_Eats', Value('hungry'))
net.add_input('Fork1', 'P1_Eats', Value('free'))
net.add_input('Fork2', 'P1_Eats', Value('free'))
net.add_output('Philosopher1', 'P1_Eats', Value('eating'))
net.add_output('Fork1', 'P1_Eats', Value('used'))
net.add_output('Fork2', 'P1_Eats', Value('used'))

net.add_transition(Transition('P2_Eats'))
net.add_input('Philosopher2', 'P2_Eats', Value('hungry'))
net.add_input('Fork2', 'P2_Eats', Value('free'))
net.add_input('Fork1', 'P2_Eats', Value('free'))
net.add_output('Philosopher2', 'P2_Eats', Value('eating'))
net.add_output('Fork2', 'P2_Eats', Value('used'))
net.add_output('Fork1', 'P2_Eats', Value('used'))

# Deadlock check
def check_deadlock(net):
    enabled_transitions = [t.name for t in net.transitions() if net.transition(t.name).enabled()]
    return len(enabled_transitions) == 0

# Simulate
print("Before firing any transition:")
print(f"Is deadlocked? {check_deadlock(net)}")

if net.transition('P1_Eats').enabled():
    net.transition('P1_Eats').fire(Substitution())
    print("Philosopher1 eats.")

print(f"Is deadlocked after P1 eats? {check_deadlock(net)}")
