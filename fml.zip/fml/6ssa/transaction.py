import threading
import random
import time

# Define the processes using Python
class OLTPSystem:
    def __init__(self):
        self.lock = threading.Lock()

    def client_request(self):
        print("Client: Sending transaction request...")
        time.sleep(1)  # Simulating delay in client request
        print("Client: Request sent.")

    def process_transaction(self):
        print("System: Processing transaction...")
        time.sleep(2)  # Simulate processing time
        # Randomly choose success or failure
        success = random.choice([True, False])
        return success

    def send_response(self, success):
        if success:
            print("System: Transaction successful. Sending confirmation...")
        else:
            print("System: Transaction failed. Sending failure notification...")

# Client and server thread functions
def client_thread(oltp_system):
    oltp_system.client_request()
    success = oltp_system.process_transaction()
    oltp_system.send_response(success)

# Create the OLTP system
oltp_system = OLTPSystem()

# Create and start the client thread
client = threading.Thread(target=client_thread, args=(oltp_system,))
client.start()

# Wait for client to finish
client.join()
