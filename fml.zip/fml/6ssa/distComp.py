import threading
import time

# Channel class for communication between parent and child
class Channel:
    def __init__(self):
        self.message = None
        self.lock = threading.Lock()

    def send(self, msg):
        with self.lock:
            self.message = msg
            print(f"Message sent: {msg}")

    def receive(self):
        with self.lock:
            msg = self.message
            self.message = None
            return msg

# Parent process
def parent_process(channel):
    print("Parent: Spawning child process and sending message...")
    child_channel = Channel()  # Parent creates a new channel
    child_thread = threading.Thread(target=child_process, args=(child_channel,))
    child_thread.start()
    time.sleep(1)  # Simulate processing time
    channel.send("Hello from Parent")
    child_thread.join()

# Child process
def child_process(channel):
    print("Child: Waiting for message from parent...")
    msg = channel.receive()
    print(f"Child: Received message: {msg}")
    time.sleep(1)  # Simulate processing time
    print("Child: Responding to parent...")
    channel.send("Message received by child")

# Create a communication channel between parent and child
channel = Channel()

# Start the parent process
parent_thread = threading.Thread(target=parent_process, args=(channel,))
parent_thread.start()

# Wait for parent to finish
parent_thread.join()

