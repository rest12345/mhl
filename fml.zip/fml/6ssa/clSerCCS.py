import time
import threading

# Define a simple channel for communication
class Channel:
    def __init__(self):
        self.message = None
        self.lock = threading.Lock()

    def send(self, msg):
        with self.lock:
            self.message = msg
            print(f"Message sent: {msg}")

    def receive(self):
        with self.lock:
            msg = self.message
            self.message = None
            return msg


# Client process
def client(channel):
    print("Client: Sending request...")
    channel.send("req")
    print("Client: Waiting for response...")
    response = channel.receive()
    print(f"Client: Received {response}")


# Server process
def server(channel):
    print("Server: Waiting for request...")
    request = channel.receive()
    print(f"Server: Received {request}")
    time.sleep(1)  # Simulate processing delay
    print("Server: Sending response...")
    channel.send("res")


# Create a communication channel
channel = Channel()

# Create client and server threads to simulate concurrency
client_thread = threading.Thread(target=client, args=(channel,))
server_thread = threading.Thread(target=server, args=(channel,))

# Start the server and client
server_thread.start()
client_thread.start()

# Wait for both to finish
client_thread.join()
server_thread.join()
