def check_ltl(trace, formula):
    # Basic LTL evaluation for: G a, F b, a U b
    if formula.startswith("G "):
        prop = formula[2:].strip()
        return all(state == prop for state in trace)

    elif formula.startswith("F "):
        prop = formula[2:].strip()
        return any(state == prop for state in trace)

    elif " U " in formula:
        p, q = map(str.strip, formula.split("U"))
        try:
            idx = trace.index(q)
            return all(state == p for state in trace[:idx])
        except ValueError:
            return False

    else:
        print("Unsupported formula format.")
        return False

# Example FSM trace and LTL formulas
if __name__ == "__main__":
    fsm_trace = ['a', 'a', 'a', 'b', 'b']

    formulas = ['G a', 'F b', 'a U b', 'F c']

    for f in formulas:
        result = check_ltl(fsm_trace, f)
        print(f"LTL Formula '{f}' is {'satisfied' if result else 'NOT satisfied'} by the trace.")
