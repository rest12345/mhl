import threading
import queue
import time

# Define a channel using queue
channel = queue.Queue()

# Sender process (Producer)
def sender():
    for i in range(5):
        print(f"[Sender] Sending: {i}")
        channel.put(i)  # Send message
        time.sleep(1)   # Simulate processing time
    channel.put("DONE")  # Signal termination

# Receiver process (Consumer)
def receiver():
    while True:
        msg = channel.get()  # Receive message (blocks until available)
        if msg == "DONE":
            print("[Receiver] Received termination signal.")
            break
        print(f"[Receiver] Got: {msg}")
        time.sleep(0.5)  # Simulate processing time

# Start threads to simulate CSP processes
if __name__ == "__main__":
    t1 = threading.Thread(target=sender)
    t2 = threading.Thread(target=receiver)

    t1.start()
    t2.start()

    t1.join()
    t2.join()

    print("CSP communication simulation complete.")
