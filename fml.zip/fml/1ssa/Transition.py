class StateMachine:
    def __init__(self):
        self.states = ['idle', 'processing', 'done']
        self.current_index = 0

    def transition(self):
        current_state = self.states[self.current_index]
        next_index = (self.current_index + 1) % len(self.states)
        next_state = self.states[next_index]
        print(f"Current state: {current_state}")
        print(f"Transitioned to: {next_state}")
        self.current_index = next_index

# Run the state machine
if __name__ == "__main__":
    sm = StateMachine()
    for _ in range(6):
        sm.transition()
