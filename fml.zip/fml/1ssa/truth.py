from itertools import product
import re

def extract_variables(expr):
    # Match variable names as uppercase letters (like A, B, C)
    tokens = re.findall(r'\b[A-Z]\b', expr)
    return sorted(set(tokens))

def generate_truth_table(expr, variables):
    truth_table = []
    for values in product([False, True], repeat=len(variables)):
        env = dict(zip(variables, values))
        try:
            result = eval(expr, {}, env)
        except Exception as e:
            print(f"Error evaluating expression: {e}")
            return None
        truth_table.append((env.copy(), result))
    return truth_table

def verify_truth_table(expr, expected_outputs):
    variables = extract_variables(expr)
    table = generate_truth_table(expr, variables)
    if table is None:
        return False

    print(f"\nTruth Table for: {expr}")
    print(" | ".join(variables) + " | Result")
    print("-" * (len(variables) * 4 + 10))
    for i, (row, result) in enumerate(table):
        var_values = [str(int(row[v])) for v in variables]
        print(" | ".join(var_values) + f" |   {int(result)}")
        if int(result) != expected_outputs[i]:
            print(f"Mismatch at row {i + 1} — expected {expected_outputs[i]}, got {int(result)}")
            return False
    return True

# Example usage
if __name__ == "__main__":
    expr = "(A and B) or (not A)"
    expected = [1, 1, 0, 1]  # Expected output from user

    is_correct = verify_truth_table(expr, expected)
    print("\nExpression is correct:", is_correct)
