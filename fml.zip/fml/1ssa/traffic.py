# import time

# class TrafficLightController:
#     def __init__(self):
#         self.states = ['RED', 'GREEN', 'YELLOW']
#         self.current_index = 0

#     def next_state(self):
#         # Print current state
#         current_state = self.states[self.current_index]
#         print(f"Traffic Light: {current_state}")
        
#         # Move to next state
#         self.current_index = (self.current_index + 1) % len(self.states)

#     def run(self, cycles=5, delay=1):
#         print("Starting Traffic Light Controller...\n")
#         for _ in range(cycles):
#             self.next_state()
#             time.sleep(delay)
#         print("\nTraffic Light Controller stopped.")

# # Run simulation
# if __name__ == "__main__":
#     controller = TrafficLightController()
#     controller.run(cycles=6, delay=1)


import tkinter as tk
import time

class TrafficLightGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Traffic Light Controller")

        self.canvas = tk.Canvas(root, width=200, height=400, bg="black")
        self.canvas.pack()

        # Create 3 lights (circles)
        self.red = self.canvas.create_oval(50, 50, 150, 150, fill="grey")
        self.yellow = self.canvas.create_oval(50, 160, 150, 260, fill="grey")
        self.green = self.canvas.create_oval(50, 270, 150, 370, fill="grey")

        self.states = ['RED', 'GREEN', 'YELLOW']
        self.current_index = 0

        # Start the controller loop
        self.update_light()

    def update_light(self):
        state = self.states[self.current_index]
        self.set_light(state)

        self.current_index = (self.current_index + 1) % 3
        # Schedule next change after 1000ms (1 second)
        self.root.after(1000, self.update_light)

    def set_light(self, state):
        colors = {"RED": "red", "YELLOW": "yellow", "GREEN": "green"}
        # Reset all to grey
        self.canvas.itemconfig(self.red, fill="grey")
        self.canvas.itemconfig(self.yellow, fill="grey")
        self.canvas.itemconfig(self.green, fill="grey")

        # Turn on the correct light
        if state == "RED":
            self.canvas.itemconfig(self.red, fill=colors[state])
        elif state == "YELLOW":
            self.canvas.itemconfig(self.yellow, fill=colors[state])
        elif state == "GREEN":
            self.canvas.itemconfig(self.green, fill=colors[state])

# Run GUI
if __name__ == "__main__":
    root = tk.Tk()
    app = TrafficLightGUI(root)
    root.mainloop()
