class TransitionSystem:
    def __init__(self):
        self.states = set()
        self.transitions = dict()
        self.labels = dict()

    def add_state(self, state, labels):
        self.states.add(state)
        self.labels[state] = set(labels)
        self.transitions[state] = []

    def add_transition(self, from_state, to_state):
        if from_state in self.transitions:
            self.transitions[from_state].append(to_state)
        else:
            self.transitions[from_state] = [to_state]

    def get_paths(self, start_state, max_depth=5):
        """Generates all paths from the start_state up to max_depth."""
        paths = []

        def dfs(path):
            if len(path) > max_depth:
                return
            paths.append(path[:])
            current = path[-1]
            for next_state in self.transitions.get(current, []):
                dfs(path + [next_state])

        dfs([start_state])
        return paths

    def check_F(self, start_state, prop):
        """F φ: eventually φ — true if some state along some path satisfies φ."""
        paths = self.get_paths(start_state)
        for path in paths:
            for state in path:
                if prop in self.labels[state]:
                    return True
        return False

    def check_G(self, start_state, prop):
        """G φ: globally (always) φ — true if all states on all paths satisfy φ."""
        paths = self.get_paths(start_state)
        for path in paths:
            for state in path:
                if prop not in self.labels[state]:
                    return False
        return True


# ----- Example Usage -----
if __name__ == "__main__":
    ts = TransitionSystem()

    # Define states and labels
    ts.add_state("s0", ["safe"])
    ts.add_state("s1", ["running"])
    ts.add_state("s2", ["safe", "done"])

    # Define transitions
    ts.add_transition("s0", "s1")
    ts.add_transition("s1", "s2")
    ts.add_transition("s2", "s2")  # loop

    # Check liveness: eventually 'done'
    print("F done from s0 (liveness):", ts.check_F("s0", "done"))  # True

    # Check safety: always 'safe'
    print("G safe from s0 (safety):", ts.check_G("s0", "safe"))    # False
