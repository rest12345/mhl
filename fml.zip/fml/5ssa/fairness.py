import time
from collections import deque

class Process:
    def __init__(self, name):
        self.name = name
        self.requested = False
        self.has_resource = False
        self.execution_log = []

    def request_resource(self):
        self.requested = True
        print(f"{self.name} requests resource.")

    def release_resource(self):
        self.has_resource = False
        self.requested = False
        print(f"{self.name} releases resource.")

    def grant_resource(self):
        self.has_resource = True
        self.execution_log.append("granted")
        print(f"{self.name} granted resource.")

    def was_fairly_scheduled(self):
        # Verifies if the process received access at least once
        return "granted" in self.execution_log


class FairScheduler:
    def __init__(self, processes):
        self.queue = deque(processes)
        self.current = None

    def run(self, cycles=6):
        print("---- Scheduler Start ----")
        for i in range(cycles):
            print(f"\nCycle {i + 1}")
            for process in list(self.queue):
                process.request_resource()

            self.current = self.queue.popleft()
            self.current.grant_resource()

            time.sleep(0.1)  # Simulated execution delay
            self.current.release_resource()

            self.queue.append(self.current)
        print("\n---- Scheduler End ----")

    def verify_fairness(self):
        print("\n---- Fairness Verification ----")
        all_fair = True
        for process in list(self.queue):
            fair = process.was_fairly_scheduled()
            print(f"{process.name} was{' ' if fair else ' not '}fairly scheduled.")
            if not fair:
                all_fair = False
        return all_fair


# ---- Main Simulation ----
if __name__ == "__main__":
    p1 = Process("P1")
    p2 = Process("P2")
    p3 = Process("P3")

    scheduler = FairScheduler([p1, p2, p3])
    scheduler.run(cycles=9)  # More cycles for stronger fairness check

    fair = scheduler.verify_fairness()
    print("\nSystem is fair." if fair else "\nSystem is not fair.")
