class KripkeStructure:
    def __init__(self):
        self.states = set()
        self.transitions = dict()
        self.labels = dict()

    def add_state(self, state, labels):
        self.states.add(state)
        self.labels[state] = set(labels)
        self.transitions[state] = []

    def add_transition(self, from_state, to_state):
        if from_state not in self.transitions:
            self.transitions[from_state] = []
        self.transitions[from_state].append(to_state)

    def ex(self, state, prop):
        """EX φ: there exists a next state where φ holds"""
        return any(prop in self.labels[next_state] for next_state in self.transitions[state])

    def ax(self, state, prop):
        """AX φ: for all next states, φ holds"""
        return all(prop in self.labels[next_state] for next_state in self.transitions[state])

    def ef(self, state, prop, visited=None):
        """EF φ: there exists a path where eventually φ holds"""
        if visited is None:
            visited = set()
        if prop in self.labels[state]:
            return True
        visited.add(state)
        for next_state in self.transitions[state]:
            if next_state not in visited:
                if self.ef(next_state, prop, visited):
                    return True
        return False

    def ag(self, state, prop, visited=None):
        """AG φ: for all paths, always φ holds"""
        if visited is None:
            visited = set()
        if state in visited:
            return True
        if prop not in self.labels[state]:
            return False
        visited.add(state)
        for next_state in self.transitions[state]:
            if not self.ag(next_state, prop, visited):
                return False
        return True


# ---- Example usage ----

if __name__ == "__main__":
    ks = KripkeStructure()
    
    # Add states with labels
    ks.add_state("s0", ["a"])
    ks.add_state("s1", ["b"])
    ks.add_state("s2", ["a", "b"])

    # Add transitions
    ks.add_transition("s0", "s1")
    ks.add_transition("s1", "s2")
    ks.add_transition("s2", "s2")

    # CTL Property Checks
    print("EX b from s0:", ks.ex("s0", "b"))      # True (s1 has b)
    print("AX b from s0:", ks.ax("s0", "b"))      # True (s0 → s1, and s1 has b)
    print("EF b from s0:", ks.ef("s0", "b"))      # True (s0 → s1 or s1 → s2)
    print("AG a from s0:", ks.ag("s0", "a"))      # False (s1 lacks 'a')
