class CTLTransitionSystem:
    def __init__(self):
        self.states = set()
        self.transitions = dict()
        self.labels = dict()

    def add_state(self, state, labels=None):
        self.states.add(state)
        self.transitions[state] = []
        self.labels[state] = set(labels) if labels else set()

    def add_transition(self, from_state, to_state):
        self.transitions[from_state].append(to_state)

    def EX(self, state, prop):
        """EX φ: Exists next state where φ holds"""
        return any(prop in self.labels.get(s, []) for s in self.transitions[state])

    def AX(self, state, prop):
        """AX φ: All next states must satisfy φ"""
        next_states = self.transitions[state]
        return all(prop in self.labels.get(s, []) for s in next_states)

    def EF(self, start, prop, max_depth=5):
        """EF φ: Exists a path where eventually φ holds"""
        visited = set()

        def dfs(state, depth):
            if depth > max_depth or state in visited:
                return False
            if prop in self.labels.get(state, []):
                return True
            visited.add(state)
            return any(dfs(s, depth + 1) for s in self.transitions[state])

        return dfs(start, 0)

    def AG(self, start, prop, max_depth=5):
        """AG φ: All paths must always satisfy φ"""
        visited = set()

        def dfs(state, depth):
            if depth > max_depth:
                return True
            if prop not in self.labels.get(state, []):
                return False
            if state in visited:
                return True
            visited.add(state)
            return all(dfs(s, depth + 1) for s in self.transitions[state])

        return dfs(start, 0)


# ----- Example Usage -----
if __name__ == "__main__":
    ts = CTLTransitionSystem()

    # Add states and their labels
    ts.add_state("s0", ["start"])
    ts.add_state("s1", ["ready"])
    ts.add_state("s2", ["safe"])
    ts.add_state("s3", ["fail"])

    # Add transitions
    ts.add_transition("s0", "s1")
    ts.add_transition("s1", "s2")
    ts.add_transition("s2", "s3")
    ts.add_transition("s3", "s3")  # self-loop

    # CTL checks
    print("EX ready from s0:", ts.EX("s0", "ready"))     # True
    print("AX safe from s1:", ts.AX("s1", "safe"))       # True
    print("EF fail from s0:", ts.EF("s0", "fail"))       # True
    print("AG safe from s0:", ts.AG("s0", "safe"))       # False
