class TransitionSystem:
    def __init__(self):
        self.states = set()
        self.transitions = dict()

    def add_state(self, state):
        self.states.add(state)
        if state not in self.transitions:
            self.transitions[state] = []

    def add_transition(self, from_state, to_state):
        if from_state in self.transitions:
            self.transitions[from_state].append(to_state)
        else:
            self.transitions[from_state] = [to_state]
        self.add_state(to_state)  # ensure target is registered

    def find_deadlocks(self):
        """Return all deadlock states: states with no outgoing transitions."""
        deadlocks = []
        for state in self.states:
            if len(self.transitions.get(state, [])) == 0:
                deadlocks.append(state)
        return deadlocks


# ----- Example Usage -----
if __name__ == "__main__":
    ts = TransitionSystem()

    # Define states
    ts.add_state("s0")
    ts.add_state("s1")
    ts.add_state("s2")
    ts.add_state("s3")  # will be deadlock

    # Define transitions
    ts.add_transition("s0", "s1")
    ts.add_transition("s1", "s2")
    ts.add_transition("s2", "s0")  # cycle back
    # s3 has no outgoing transitions

    # Check deadlocks
    deadlock_states = ts.find_deadlocks()
    print("Deadlock States:", deadlock_states)
